let drone;
let bois = [];
let curral;
let pontos = 0;
let gameState = 'playing'; // 'playing', 'win', 'gameOver'

// --- Imagens (opcional, mas recomendado para o tema) ---
let droneImg;
let boiImg;
let curralImg;

function preload() {
  // Descomente e substitua os caminhos pelas suas próprias imagens se quiser usá-las!
  // droneImg = loadImage('assets/drone.png');
  // boiImg = loadImage('assets/boi.png');
  // curralImg = loadImage('assets/curral.png');
}

// --- Classes para os objetos do jogo ---

class Drone {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 40;
    this.speed = 5;
  }

  display() {
    if (droneImg) {
      image(droneImg, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    } else {
      fill(50, 100, 150); // Cor azul escura para o drone
      rect(this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    }
  }

  move() {
    // Movimento com as setas do teclado
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Garante que o drone não saia da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }
}

class Boi {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 30;
    this.speed = 0.8; // Velocidade base do boi
  }

  display() {
    if (boiImg) {
      image(boiImg, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    } else {
      fill(139, 69, 19); // Cor marrom para o boi
      ellipse(this.x, this.y, this.size, this.size);
    }
  }

  // Lógica de movimento do boi, influenciada pelo drone
  update(drone) {
    let d = dist(this.x, this.y, drone.x, drone.y);

    if (d < 100) { // Se o drone estiver perto (100 pixels de raio)
      // Calcula a direção para empurrar o boi
      let angle = atan2(this.y - drone.y, this.x - drone.x);
      let pushForce = map(d, 0, 100, this.speed * 2, 0); // Força de empurrão maior quanto mais perto
      this.x += cos(angle) * pushForce;
      this.y += sin(angle) * pushForce;
    } else {
      // Movimento aleatório suave quando o drone está longe
      this.x += random(-this.speed * 0.2, this.speed * 0.2);
      this.y += random(-this.speed * 0.2, this.speed * 0.2);
    }

    // Garante que o boi não saia da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }
}

class Curral {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.width = w;
    this.height = h;
  }

  display() {
    if (curralImg) {
      image(curralImg, this.x, this.y, this.width, this.height);
    } else {
      fill(100, 200, 100, 150); // Verde claro semi-transparente para o curral
      rect(this.x, this.y, this.width, this.height);
      fill(0);
      textSize(18);
      textAlign(CENTER, CENTER);
      text("CURRAL", this.x + this.width / 2, this.y + this.height / 2);
    }
  }

  // Verifica se um boi está dentro do curral
  contains(boi) {
    return boi.x > this.x && boi.x < this.x + this.width &&
           boi.y > this.y && boi.y < this.y + this.height;
  }
}

// --- Funções principais do p5.js ---

function setup() {
  createCanvas(800, 600);
  drone = new Drone();
  curral = new Curral(width - 120, height - 120, 100, 100); // Curral no canto inferior direito

  // Cria 5 bois em posições aleatórias no lado esquerdo do campo
  for (let i = 0; i < 5; i++) {
    bois.push(new Boi(random(50, width / 2), random(50, height - 50)));
  }
}

function draw() {
  background(135, 206, 235); // Céu azul

  if (gameState === 'playing') {
    // Desenha o campo (gramado)
    fill(100, 180, 100);
    rect(0, 0, width, height);

    curral.display();

    drone.move();
    drone.display();

    // Atualiza e exibe os bois, verifica a entrega
    for (let i = bois.length - 1; i >= 0; i--) {
      let boi = bois[i];
      boi.update(drone);
      boi.display();

      if (curral.contains(boi)) {
        pontos++;
        bois.splice(i, 1); // Remove o boi que entrou no curral
        // Adiciona um novo boi em algum lugar do campo para manter o jogo ativo
        bois.push(new Boi(random(50, width / 2), random(50, height - 50)));
      }
    }

    // Exibe o placar
    fill(0);
    textSize(24);
    text(`Pontos: ${pontos}/10`, 20, 30);

    // Verifica condição de vitória
    if (pontos >= 10) {
      gameState = 'win';
    }

  } else if (gameState === 'win') {
    background(50, 200, 50); // Fundo verde de vitória
    fill(255);
    textSize(60);
    textAlign(CENTER, CENTER);
    text("VOCÊ VENCEU!", width / 2, height / 2 - 40);
    textSize(24);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 20);
  }
}

function keyPressed() {
  if (keyCode === 82 && (gameState === 'win' || gameState === 'gameOver')) { // 'R' para Reiniciar
    resetGame();
  }
}

function resetGame() {
  pontos = 0;
  bois = [];
  drone = new Drone();
  for (let i = 0; i < 5; i++) {
    bois.push(new Boi(random(50, width / 2), random(50, height - 50)));
  }
  gameState = 'playing';
}